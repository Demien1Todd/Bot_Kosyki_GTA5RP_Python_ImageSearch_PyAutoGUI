from python_imagesearch.imagesearch import *
import pyautogui 

#Написание скрипта:
while True:
    Down = imagesearch("Down.jpg") 
    if Down[0] != -1: 
        print("position: ", Down[0], Down[1]) 
        pyautogui.press('down') 
    else: 
        print("Down не найдена")
    Right = imagesearch("Right.jpg") 
    if Right[0] != -1: 
        print("position: ", Right[0], Right[1]) 
        pyautogui.press('right') 
    else: 
        print("Right не найдена")
    Rright = imagesearch("Rright.jpg") 
    if Rright[0] != -1: 
        print("position: ", Rright[0], Rright[1]) 
        pyautogui.press('up') 
    else: 
        print("Rright не найдена")
    Left = imagesearch("Left.jpg") 
    if Left[0] != -1: 
        print("position: ", Left[0], Left[1]) 
        pyautogui.press('left') 
    else: 
        print("Left не найдена")
    pyautogui.press('e')
    